# Agent Trace capture

Exported 2026-11-20T14:14:01+00:00 from Codex. Capture ID `3834ffe24810efdbc9d4a8deeabbe3eb0f8b8dafa32c840fe2913a9d0b9aae33`.
This file set is the evidence. Decide for yourself which commands and results to read;
the person who sent it may not have anticipated your questions.

## Conversations in this capture

| Snapshot ID (legacy: window) | Session | Nickname | Scope role | Items |
|---|---|---|---|---:|
| `99b68b393250…` | `01a19dea-e6d8-7c73-8542-c3746a473b54` | — | root of this capture; source parent not recorded here | 5 |

Selection: selected root conversation only.
Cutoff: each conversation as saved when read at export (2026-11-20T14:14:01+00:00).
The five selected records published in examples/validation-history: one Agent Trace development worker on 2 November 2026, with the checkout path replaced and session metadata reduced. Other records from that worker are not included.

Descendant discovery was not requested; this does not establish that no other workers existed.

## Read it

Python 3.9 or later, standard library only. Run from this folder (or pass `--capture <file>.trace.zip`):

```sh
python capture_reader.py verify
python capture_reader.py --text handoff
python capture_reader.py list_windows
python capture_reader.py list_items --failed-only
python capture_reader.py list_items --agent-name <session or nickname> --kind CommandExecution
python capture_reader.py search_contents --query "AssertionError" --all-windows
python capture_reader.py read_item --agent-name <session> --item-id <item> --field /aggregated_output --offset-chars 0 --limit-chars 4000
python capture_reader.py cite "agent-trace://…"
```

The command names resemble Codex's history tools. Here a legacy `window_id` identifies one frozen
conversation snapshot; it is not a model context window. `--failed-only` filters recorded nonzero
exit/status/error values, not failed tests. A status of zero does not establish that every test passed.

## Cite what you used

Every result includes a `cite` value such as
`agent-trace://<window>/<item>?field=/aggregated_output&chars=120-180`. Put these citations beside each
claim in your answer. Ranges count Unicode characters in a decoded string field or the canonical JSON
rendering of a non-string value; they are not offsets into the original JSONL bytes. On the sender's
machine Agent Trace opens that same captured value after import, even after the conversation moves on.
Quote only what a citation's range contains. Search supplies both a match citation and a passage citation.

## Limits

- Only the conversations listed in windows are included; anything else on the sender's machine is not.
- Each conversation was read once at export; the files were read one after another, so workers are not one atomic instant.
- Items are the native records Codex saved. Unsupported records, outer wrappers and encrypted fields are not included.
- Codex may have shortened an output before saving it; bytes that were never saved cannot be recovered.
- No recorded command was rerun. A passing test here says nothing about a later checkout.
- Without pipefail, a pipeline normally reports its last command's status (for example `pytest | tail`); read the output too.
- Hashes check internal consistency, not who exported the capture or who ran a command.
- Nothing here shows which bytes a model was sent. A saved tool output is evidence the tool returned it, not that a model read it.

## Privacy

These are saved working sessions. They can contain file paths, commands, outputs and anything a
tool printed. Read before passing them on.
